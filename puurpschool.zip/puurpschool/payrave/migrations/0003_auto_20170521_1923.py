# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('payrave', '0002_auto_20170517_1538'),
    ]

    operations = [
        migrations.RemoveField(
            model_name='payravemodel',
            name='data_countryguest_name',
        ),
        migrations.RemoveField(
            model_name='payravemodel',
            name='data_payment_methodguest_name',
        ),
        migrations.AddField(
            model_name='payravemodel',
            name='data_country',
            field=models.CharField(max_length=50, blank=True, default='Guest'),
        ),
        migrations.AddField(
            model_name='payravemodel',
            name='data_payment_method',
            field=models.CharField(max_length=50, blank=True, default='Guest'),
        ),
        migrations.AlterField(
            model_name='payravemodel',
            name='data_currency',
            field=models.CharField(max_length=50, blank=True, default='Guest'),
        ),
        migrations.AlterField(
            model_name='payravemodel',
            name='data_custom_description',
            field=models.CharField(max_length=50, blank=True, default='Guest'),
        ),
        migrations.AlterField(
            model_name='payravemodel',
            name='data_custom_logo',
            field=models.CharField(max_length=100, default='Guest'),
        ),
        migrations.AlterField(
            model_name='payravemodel',
            name='data_exclude_banks',
            field=models.CharField(max_length=50, blank=True, default='Guest'),
        ),
        migrations.AlterField(
            model_name='payravemodel',
            name='data_pay_button_text',
            field=models.CharField(max_length=50, blank=True, default='Guest'),
        ),
        migrations.AlterField(
            model_name='payravemodel',
            name='data_redirect_url',
            field=models.CharField(max_length=50, blank=True, default='Guest'),
        ),
    ]
